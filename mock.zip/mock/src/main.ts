
// Just an example function in a code module, so we can demo 
// testing arbitrary TypeScript functions outside React
export function zero() {
    return 0
}